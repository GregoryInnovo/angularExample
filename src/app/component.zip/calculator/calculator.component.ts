import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent implements OnInit {

  constructor() { 
    this.titleResult = "Default Title";
    this.contentResult = "Default Content: Lorem ipsum dolor sit amet";
  }

  ngOnInit(): void {
  }

  titleResult : string;
  contentResult : string;

  num1 : number = 0;
  num2 : number = 0;
  operation : number = 0;

  number1(n : string) {
    this.titleResult = n;
  }
  
  
  textDesc(n : string) {
    this.contentResult = n;
  }
  // funcion que calcula para operación aritmética de acuerdo a la selñeccion del usuario
  // Calculate() {
  //     var result = 0;
  //     console.log("Hay que calcular");
  //     this.GetInputs();

  //     if(!isNaN(this.num1) && !isNaN(this.num2)){
  //         if(operation=="sum"){
  //             result = num1+num2;
  //         }else if(operation=="res"){
  //             result = num1-num2;
              
  //         }else if(operation=="mul"){
              
  //             result = num1*num2;
  //         }else {
  //             result = num1/num2;   
  //         }
  //         console.log("Result", result);
          
  //     } else {
  //         result = "Ingresa el número faltante"
  //     }
      
  //     ShowResult(result);
  // }

  // // funcion que obtine los valor de los campos por el usuaria
  //  GetInputs() {

  // }

  // /* 
  // *  
  // * @param {*} result Parámetro de entra con el valor que se muestra en el documento
  // */
  // ShowResult = (result) => {
  //     document.getElementById("result").innerHTML = result;
  // }
}
